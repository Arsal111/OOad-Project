/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aenam
 */
public class Electricity {
    String selectedCompany;
    
    public Electricity()
    {
        selectedCompany=null;
    }
    public void setCompany(String s)
    {
        selectedCompany=s;
    }
    
    public String getCompany()
    {
        return selectedCompany;
    }
}
