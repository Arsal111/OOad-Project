/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aenam
 */
public class User {
    String name, CNIC, PIN;
    int ID;
    User()
    {
        name=null;
        CNIC=null;
        PIN=null;
        ID=0;
    }
    User(String n, String c, String p, int id)
    {
        name=n;
        CNIC=c;
        PIN=p;
        ID=id;
    }
    String getName()
    {
        return name;
    }
    String getPIN()
    {
        return PIN;
    }
    String getCNIC()
    {
        return CNIC;
    }
    int getID()
    {
        return ID;
    }
}
