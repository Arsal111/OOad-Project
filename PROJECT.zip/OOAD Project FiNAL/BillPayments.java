/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aenam
 */
public class BillPayments {
    String BillsArray[];
    
    BillPayments()
    {
        BillsArray=new String[5];
        //for(int i=0;i<5;i++)
        //{
          //  BillsArray[i]=null; //initially bills are null. As soon as 
        //}
        BillsArray[0]="Electricity";
        BillsArray[1]="Gas";
        BillsArray[2]="Telephone";
        BillsArray[3]="Water";
        BillsArray[4]="Internet";
    }
    String[] getBillsList()
    {
        return BillsArray;
    }
    
    
}
